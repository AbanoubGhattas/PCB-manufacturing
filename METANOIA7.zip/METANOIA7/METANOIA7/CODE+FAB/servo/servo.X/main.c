#include <xc.h>

// Configuration bits
#pragma config FOSC = EXTRCCLK  // Oscillator Selection bits (RC oscillator: CLKOUT function on GP4/OSC2/CLKOUT pin, RC on GP5/OSC1/CLKIN)
#pragma config WDTE = ON        // Watchdog Timer Enable bit (WDT enabled)
#pragma config PWRTE = OFF      // Power-Up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // GP3/MCLR pin function select (GP3/MCLR pin function is MCLR)
#pragma config BOREN = ON       // Brown-out Detect Enable bit (BOD enabled)
#pragma config CP = OFF         // Code Protection bit (Program Memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)

#define _XTAL_FREQ 4000000  // This is the speed your controller is running at

// Function to set the servo position
void set_servo_angle(int angle) {
    // Map the angle to a pulse width between 1ms and 2ms
    if (angle==1){
    GP2 = 1;
        __delay_ms(1);
    GP2 = 0;
        __delay_ms(19);
    }
    else if (angle==2){
    GP2 = 1;
        __delay_ms(2);
    GP2 = 0;
        __delay_ms(18);
    }
    else{GP2 = 0;}
}
void main(void) {
    // Set GP2 as output for the servo control signal
    TRISIObits.TRISIO2 = 0;

    // Set GP0 and GP1 as inputs for the analog signals
    TRISIObits.TRISIO0 = 1;
    TRISIObits.TRISIO1 = 1;

    // Set GP0 and GP1 as analog inputs
    ANSELbits.ANS0 = 1;
    ANSELbits.ANS1 = 1;

    // Set the ADC clock frequency (Fosc/8)
    ANSELbits.ADCS = 1;

    // Enable the ADC
    ADCON0bits.ADON = 1;

    while(1) {
        // Read the analog inputs
        ADCON0bits.CHS = 0;  // Select GP0
        ADCON0bits.GO = 1;  // Start the conversion
        while(ADCON0bits.GO);  // Wait for the conversion to finish
        int analog_input_0 = ADRESH;

        ADCON0bits.CHS = 1;  // Select GP1
        ADCON0bits.GO = 1;  // Start the conversion
        while(ADCON0bits.GO);  // Wait for the conversion to finish
        int analog_input_1 = ADRESH;

        // Now you can use the values from analog_input_0 and analog_input_1 in your program

        // Set the servo angle based on the value from one of the analog inputs
        if (analog_input_0>analog_input_1){set_servo_angle(1);}
        else {set_servo_angle(2);}

        // Wait 20ms for the servo to update
        __delay_ms(20);
    }
}